#include "myHttp.h"
#include "DownloadChunk.h"
#include "strsafe.h"
#include "Win7ProgressTaskbar.h"
#include "DMFile.h"


extern HWND hWnd;


namespace myHttp
{


bool DownloadSingleWithSize()
{HINTERNET hReq=0;bool r=false;
 for(;!hReq;)hReq = WinHttpOpenRequest( hConnect, L"GET",memFileHeader.URLpath,0/*L"HTTP/1.1"*/,
										WINHTTP_NO_REFERER,WINHTTP_DEFAULT_ACCEPT_TYPES,RequestFlags);
 BOOL b=FALSE;
 for(;!b;)b=WinHttpSendRequest(hReq,WINHTTP_NO_ADDITIONAL_HEADERS,0,WINHTTP_NO_REQUEST_DATA,0,0,0);

 b=FALSE;for(;!b;)b=WinHttpReceiveResponse(hReq,NULL);

 memFileHeader.sizeDownloaded=0;
 memFileHeader.flag=1;

 SetFilePointer(DMFile::f,0,NULL,FILE_BEGIN);

 fSpeed = 0.0f;
 fTimeToDownload = 0.0f;
 DWORD gtck = GetTickCount();

 DWORD dwDownloaded,dwSize[2]={4096,0};char *buf = (char*)malloc(dwSize[0]);
 int percent=0;
 do 
 {// Check for available data.
  dwSize[1] = 0;
  for(;!WinHttpQueryDataAvailable(hReq,&dwSize[1]);)Sleep(50);

  if(dwSize[0]<=dwSize[1])
  {dwSize[0]=dwSize[1]+1;
   buf = (char*)realloc(buf,dwSize[0]);
  }
  if(!buf)
  {StringCchPrintf(ErrString,260,L"Out of memory");
   goto End;
  }

  // Read the Data.
  //ZeroMemory(buf, dwSize[0]);

  dwDownloaded=0;
  if(!WinHttpReadData(hReq,(LPVOID)buf,dwSize[1],&dwDownloaded))
  {StringCchPrintf(ErrString,260,L"Err. WinHttpReadData");
   goto End;
  }
  
  if(dwDownloaded)
  {DWORD writed[2];
   WriteFile(DMFile::f,buf,dwDownloaded,&writed[0],NULL);//dwonloaded size kerak emas;
   memFileHeader.sizeDownloaded+=(int)dwDownloaded;
   WriteFile(DMFile::f,memFileHeader.URL,memFileHeader.URLSize*sizeof(wchar_t),&writed[0],NULL);
   WriteFile(DMFile::f,&memFileHeader,sizeof(memFileHeader),&writed[1],NULL);
   LONG li = ((LONG)writed[0])+((LONG)writed[1]);
   SetFilePointer(DMFile::f,-li,NULL,FILE_CURRENT);

   Win7PrgrsTaskbar::Send();
   SendMessage(hWnd,WM_USER,0,9);
   //{SendToExtMaster(memFileHeader.URLpath,Win7PrgsTaskbar::perc,memFileHeader.sizeFull);
   DWORD gtcke = GetTickCount();

   if(bPaused)
   {for(;bPaused;)Sleep(500);
    gtcke = gtck = GetTickCount();
	fSpeed = 0.0f;
   }
   else
   {DWORD delta = gtcke>gtck?gtcke-gtck:0;
	fTimeToDownload += delta;
    gtck = gtcke;
    if(delta && dwDownloaded && memFileHeader.sizeDownloaded != dwDownloaded)
	 fSpeed = (float)dwDownloaded / (float)delta;
 }}}
 while(dwDownloaded>0 && (!bForceClose));

 if(0==dwDownloaded)
 {r=true;
  SetEndOfFile(DMFile::f);
 }
End:
 if(buf)free(buf);
 WinHttpCloseHandle(hReq);
 return r;
}

}//end of namespace
/*
namespace DMFile
{

bool CheckForDMFileSingleWithSize(HANDLE f)
{if(INVALID_SET_FILE_POINTER==SetFilePointer(f,-sizeof(memFileHeader),NULL,FILE_END))return false;
 DWORD readed=0;FileHeader fh;
 if(!ReadFile(f,&fh,sizeof(fh),&readed,NULL))return false;
 if(readed!=sizeof(fh))return false;
 return false;
}

}*/