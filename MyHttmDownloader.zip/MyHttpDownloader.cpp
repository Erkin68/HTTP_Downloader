// MyHttpDownloader.cpp : Defines the entry point for the application.
// Men bu yerda asosiy quyidagi funk.larni ishlatmoqchi edim:
// InternetOpenURL InternetReadFile InternetQueryDataAvailable InternetOpen InternetSetFilePointer

#include "windows.h"
#include "targetver.h"
#include "resource.h"
#include "commctrl.h"
#include "DownloadChunk.h"
#include "DMFile.h"
#include "config.h"
#include "myHttp.h"
#include "Win7ProgressTaskbar.h"
#include "strsafe.h"


#define MAX_LOADSTRING 100
#define MIN_WIN_WIDTH  400
#define MIN_WIN_HEIGHT 280

int scrnWidth(0);
int scrnHeight(0);
void DrawProgress(HDC,RECT*,int);
extern wchar_t crFilePthAndName[512];

// Global Variables:
HINSTANCE hInst;								// current instance
HWND  hWnd,hWndURL,hWndPauseBtn;
HBRUSH blueBrsh,prgrsBckBrsh,prgrsLineBrsh,prgrsRedBrsh,prgrsBrsh;HFONT hFnt;HPEN prgrsLinePen;
TCHAR szTitle[MAX_LOADSTRING];					// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];			// the main window class name
HANDLE hThread=0;

// Forward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
void				OnPaint(HDC,int state=0);
extern void			DownloadThread();

//http://developer.android.com/sdk/index.html
//http://developer.android.com/sdk/installing/index.html?pkg=tools
//http://www.uff.uz/images/files/mour7771.jpg
//http://soft.snet.uz/default.html
//http://muz.uz/engine/modules/mservice/download.php
//http://soft.snet.uz/internet/Downloaders/downloadMaster/dmaster.exe
//http://dl.mp3.uz/dl/video/6875/Hilary_Duff_-_Tattoo.mp4
//L"http://dl.mp3.uz/dl/single/417537/DJ_Antoin_-_Holidaye_Feat_Akon.mp3",//www.mp3.uz
//http://programm.uz/getfile.php?fname=Shaxmat.zip&key=288061432
//http://programm.uz/dwnldFiles/Shaxmat.zip
//http://programm.uz/getfile.php?fname=SINO/Sino.msi&key=288062668 dan 'Sino.msi' ni chiqarayapti;
//http://okay.uz/data/image/045689.jpg
//URL to lpCmdLine;
int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

 	// TODO: Place code here.
	MSG msg;
	HACCEL hAccelTable;

	if(!memFileHeader.SetURLFromCmndLine())
	{MessageBox(NULL,L"Undefined URL string...",L"Error...",MB_OK);
	 return 0;
	}//MessageBox(NULL,(LPWSTR)memFileHeader.URL,L"URL:",MB_OK);if(' ' == memFileHeader.URL[0])MessageBox(NULL,(LPWSTR)memFileHeader.URL,L"Err:",MB_OK);

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_MYDM, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	config::Read();

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow))
		return FALSE;

	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_MYDM));

    DWORD trid;hThread=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)DownloadThread,0,0,&trid);
    //SetThreadPriority(hThread,THREAD_PRIORITY_ABOVE_NORMAL);

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0))
	{	if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{	TranslateMessage(&msg);
			DispatchMessage(&msg);
	}	}

	//config::Save();
	return (int) msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage are only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_MYDM));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)GetStockObject(GRAY_BRUSH);
	wcex.lpszMenuName	= MAKEINTRESOURCE(IDC_MYDM);
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_MYDM_SMALL));

	return RegisterClassEx(&wcex);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hInst = hInstance; // Store instance handle in our global variable

   wchar_t s[512];StringCchPrintf(s,512,L"%s% URL: %s",szTitle,memFileHeader.URL);
   HWND hWnd = CreateWindow(szWindowClass, s/*zTitle*/, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, MIN_WIN_WIDTH, MIN_WIN_HEIGHT, NULL, NULL, hInstance, NULL);
   if (!hWnd)
      return FALSE;

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

int OnCreate(HWND wnd)
{hWnd = wnd;
 InitCommonControls();
 blueBrsh = CreateSolidBrush(RGB(0,0,255));
 prgrsBckBrsh = CreateSolidBrush(RGB(128,0,255));
 prgrsLineBrsh = CreateSolidBrush(RGB(18,232,237));
 prgrsRedBrsh = CreateSolidBrush(RGB(255,0,0));
 prgrsBrsh = CreateSolidBrush(RGB(24,243,112));
 prgrsLinePen = CreatePen(PS_DOT|PS_GEOMETRIC|PS_ENDCAP_ROUND, 2, RGB(18,232,237));

 LOGFONT logFont = {0};
 logFont.lfHeight = -14;
 logFont.lfItalic = TRUE;
 logFont.lfWeight = FW_ULTRABOLD;
 logFont.lfCharSet = DEFAULT_CHARSET;
 StringCchPrintf(logFont.lfFaceName, 32, L"Verdana");
 hFnt=CreateFontIndirect(&logFont);



 //HWND hWndPB = CreateWindowEx(0, PROGRESS_CLASS, L"", WS_CHILD|WS_VISIBLE,
 //							  CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, wnd, NULL, hInst, NULL);
 //SendMessage(hWndPB, PBM_SETRANGE, 0, MAKELPARAM(0, 1000)); 
 //SendMessage(hWndPB, PBM_SETSTEP, (WPARAM) 500, 0); 


 hWndURL = CreateWindow(L"EDIT",				// predefined class 
                        memFileHeader.URL,      //L"http://dl.mp3.uz/dl/single/417537/DJ_Antoin_-_Holidaye_Feat_Akon.mp3",//www.mp3.uz  http://soft.snet.uz/internet/Downloaders/downloadMaster/dmaster.exe
						WS_CHILD | WS_VISIBLE | // | WS_HSCROLL |
                        ES_LEFT | ES_AUTOHSCROLL, 
                        36, 5, 150, 18,			// set size in WM_SIZE message 
                        wnd,					// parent window 
                        (HMENU) 1,				// edit control ID 
                        hInst,
                        NULL);					// pointer not needed 
 if(!hWndURL)return -1;
 SendMessage(hWndURL,WM_SETFONT,(WPARAM)hFnt,TRUE);
 hWndPauseBtn = CreateWindow(L"BUTTON",				// predefined class 
                        L"Pause",
						WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
                        36, 44, 150, 32,		// set size in WM_SIZE message 
                        wnd,					// parent window 
                        (HMENU) 2,				// edit control ID 
                        hInst,
                        NULL);					// pointer not needed 
 if(!hWndPauseBtn)return -1;
 SendMessage(hWndPauseBtn,WM_SETFONT,(WPARAM)hFnt,TRUE);
/*hwndPB = CreateWindowEx(0, PROGRESS_CLASS,
        (LPTSTR) NULL, WS_CHILD | WS_VISIBLE,
        rcClient.left, rcClient.bottom - cyVScroll, rcClient.right, cyVScroll, 
        hwndParent, (HMENU) 0, g_hinst, NULL);

  SendMessage(hwndPB, PBM_SETRANGE, 0,
        MAKELPARAM(0, cb / 2048)); 
    SendMessage(hwndPB, PBM_SETSTEP, (WPARAM) 1, 0); 

 */
 Win7PrgrsTaskbar::Init();
 return 0;
}

VOID OnDestroy()
{DeleteObject(blueBrsh);
 DeleteObject(prgrsBckBrsh);
 DeleteObject(prgrsLinePen);
 DeleteObject(prgrsLineBrsh);
 DeleteObject(prgrsRedBrsh);
 DeleteObject(prgrsBrsh);
 DeleteObject(hFnt);
 DMFile::Close();
 myHttp::Close();
 Win7PrgrsTaskbar::Close();
}
BOOL OnResize(LPARAM lParam)
{static BOOL bIn=FALSE;
 if(bIn)return FALSE;
 bIn=TRUE;
 scrnWidth = LOWORD(lParam);
 scrnHeight = HIWORD(lParam);
 BOOL bRet=TRUE;
 if(scrnWidth<MIN_WIN_WIDTH || scrnHeight<MIN_WIN_HEIGHT)//Shundan past bo'lsa,o'zgartirmasun;
 {if(scrnWidth<MIN_WIN_WIDTH)scrnWidth=MIN_WIN_WIDTH;
  if(scrnHeight<MIN_WIN_HEIGHT)scrnHeight=MIN_WIN_HEIGHT;
  //lParam=MAKELPARAM(dx,dy);
  RECT r;GetWindowRect(hWnd,&r);
  MoveWindow(hWnd,r.left,r.top,scrnWidth,scrnHeight,TRUE);
  bRet = FALSE;
 }MoveWindow(hWndURL,36,5,scrnWidth-45,18,TRUE);
  //MoveWindow(hWndURL,36,24,150,32,TRUE);
 bIn=FALSE;
 return bRet;
}
//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;

	switch (message)
	{
	case WM_CREATE:
		return OnCreate(hWnd);
	case WM_SIZE:
		OnResize(lParam);
		return 0;
	case WM_COMMAND:
		wmId    = LOWORD(wParam);
		wmEvent = HIWORD(wParam);
		// Parse the menu selections:
		switch (wmId)
		{
		case IDM_ABOUT:
			DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
			break;
		case IDM_EXIT:
			SendMessage(hWnd,WM_CLOSE,0,0);
			break;
		case 2://Pause:
			myHttp::bPaused = !myHttp::bPaused;
			SetWindowText(hWndPauseBtn,myHttp::bPaused?L"Continue":L"Pause");
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;
	case WM_CTLCOLOREDIT:
		SetTextColor((HDC)wParam,RGB(0,255,75));
		SetBkColor((HDC)wParam,RGB(0,0,155));
		return (LRESULT)blueBrsh;
	//case WM_CTLCOLORBTN:
	//	return (LRESULT)blueBrsh;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		 OnPaint(ps.hdc);
		EndPaint(hWnd, &ps);
		return 0;
	case WM_USER:
		switch(wParam)
		{case 0://Paint:
		  OnPaint(0,(int)lParam);
		 break;
		}
		return 0;
	case WM_CLOSE:
		if(!hThread)DestroyWindow(hWnd);
		else
		{if(IDYES==MessageBox(hWnd,L"Downloader thread is in the working state.",L"Are you want terminate thread?",MB_YESNO))
		  myHttp::bForceClose=true;
		}
		return 0;
	case WM_DESTROY:
		OnDestroy();
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

int paintState=0;
void OnPaint(HDC DC,int state)
{HDC dc=DC?DC:GetDC(hWnd);
 if(state>0)paintState=state;
 SetBkMode(dc,TRANSPARENT);//SetBkColor(dc,RGB(0,0,255);
 SetTextColor(dc,RGB(255,255,0));
 RECT rWnd;GetClientRect(hWnd,&rWnd);
 //RECT r={5,5,scrnWidth-5,20};
 //if(memFileHeader.URL)
 // DrawText(dc,memFileHeader.URL,memFileHeader.URLSize-1,&r,DT_LEFT);
 TextOut(dc,1,5,L"URL:",4);
 wchar_t s[260];StringCchPrintf(s,260,L"Wr.to: %s",crFilePthAndName);//memFileHeader.crFileName);
 TextOut(dc,1,25,s,(int)wcslen(s));
 RECT r={5,rWnd.bottom-16,scrnWidth-5,rWnd.bottom};
 FillRect(dc,&r,blueBrsh);
 switch(paintState)
 {case 1://DownloadThread beginning:
   DrawText(dc,L"Starting downloading, try to open existing dm-file with same name...",-1,&r,DT_LEFT);
   DrawProgress(dc,&rWnd,0);
  break;
  case 2://DMFile::Opening wait:
   DrawText(dc,L"Try to open existing dm-file with same name...",-1,&r,DT_LEFT);
   DrawProgress(dc,&rWnd,1);
  break;
  case 3://Http init:
   DrawText(dc,L"Http functions initializing...",-1,&r,DT_LEFT);
   DrawProgress(dc,&rWnd,0);
  break;
  case 4:
   DrawText(dc,L"Wait for Http functions initializing...",-1,&r,DT_LEFT);
   DrawProgress(dc,&rWnd,1);
  break;
  case 5:
   DrawText(dc,L"Get download options from server...",-1,&r,DT_LEFT);
   DrawProgress(dc,&rWnd,0);
  break;
  case 6:
   DrawText(dc,L"Wait for getting download options from server...",-1,&r,DT_LEFT);
   DrawProgress(dc,&rWnd,1);
  break;
  case 7:
   DrawText(dc,L"Starting download process...",-1,&r,DT_LEFT);
   DrawProgress(dc,&rWnd,0);
  break;
  case 8:
   StringCchPrintf(s,260,L"Downloading,choice type: single. Size:unknown. Downloaded: %d bytes. Speed: %.2f KB/s.",memFileHeader.sizeDownloaded,myHttp::fSpeed);
   DrawText(dc,s,-1,&r,DT_LEFT);
   DrawProgress(dc,&rWnd,2);
  break;
  case 9:
   StringCchPrintf(s,260,L"Downloading,choice type:single. Size: %d bytes. Downloaded: %d bytes, %d %s. Speed: %.2f KB/s.",
	   memFileHeader.sizeFull,memFileHeader.sizeDownloaded,Win7PrgrsTaskbar::perc,L"%",myHttp::fSpeed);
   DrawText(dc,s,-1,&r,DT_LEFT);
   DrawProgress(dc,&rWnd,3);
  break;
  case 10:
   StringCchPrintf(s,260,L"Downloading,choice type:multipart,constant parts. Size: %d bytes. Downloaded: %d bytes, %d %s. Speed: %.2f KB/s.",
	   memFileHeader.sizeFull,memFileHeader.sizeDownloaded,Win7PrgrsTaskbar::perc,L"%",myHttp::fSpeed);
   DrawText(dc,s,-1,&r,DT_LEFT);
   DrawProgress(dc,&rWnd,4);
  break;
  case 11:
   StringCchPrintf(s,260,L"Downloading,choice type:multipart,dynamic parts.Size: %d bytes. Downloaded: %d bytes, %d %s. Speed: %.2f KB/s.",
	   memFileHeader.sizeFull,memFileHeader.sizeDownloaded,Win7PrgrsTaskbar::perc,L"%",myHttp::fSpeed);
   DrawText(dc,s,-1,&r,DT_LEFT);
   DrawProgress(dc,&rWnd,5);
  break;
 }
 if(!DC)ReleaseDC(hWnd,dc);
}

void DrawProgress(HDC dc,RECT* rWnd,int type)
{static int xShft=0,iCnt=0;static bool dir=true;
 RECT r1,r={rWnd->left+5,rWnd->bottom-40,rWnd->right-5,rWnd->bottom-20};
 int w=r.right-r.left,h=r.bottom-r.top;
 HGDIOBJ original = NULL;
 FillRect(dc,&r,prgrsBckBrsh);
 switch(type)
 {case 0://starting any process:
   r1.left=r.left+w/2-15;r1.top=r.top+h/3;r1.right=r1.left+5;r1.bottom=r1.top+5;
   FillRect(dc,&r1,prgrsLineBrsh);
   r1.left+=15;r1.right+=15;
   FillRect(dc,&r1,prgrsLineBrsh);
   r1.left+=15;r1.right+=15;
   FillRect(dc,&r1,prgrsLineBrsh);
  break;
  case 1://waiting for any process, progress to right, after to left, and so:
   if(dir)
   {xShft+=5;
	if(xShft>w-40)
    {xShft-=5;dir=!dir;
   }}else
   {xShft-=5;
	if(xShft<1)
    {xShft=0;dir=!dir;
   }}
   r1.left=xShft+r.left+5;r1.top=r.top+h/3;r1.right=r1.left+5;r1.bottom=r1.top+5;
   FillRect(dc,&r1,prgrsLineBrsh);
   r1.left+=15;r1.right+=15;
   FillRect(dc,&r1,prgrsLineBrsh);
   r1.left+=15;r1.right+=15;
   FillRect(dc,&r1,prgrsLineBrsh);
  break;
  case 2://downloading single with unknown size:
   original = SelectObject(dc,prgrsLinePen);
   if(dir){if(++xShft>14){xShft=0;if(++iCnt>2){dir=false;xShft=14;}}}
   else {if(--xShft<1){xShft=14;if(++iCnt>2){dir=true;xShft=0;}}}
   for(int x=xShft; x<w-18; x+=15)
   {MoveToEx(dc,r.left+x,r.top,NULL);
    LineTo(dc,r.left+18+x,r.top+18);
   }
   SelectObject(dc,original);
  break;
  case 3://downloading single with size:
   double f;f=0.0f;if(memFileHeader.sizeFull>0)f=(double)memFileHeader.sizeDownloaded/(double)memFileHeader.sizeFull;
   r1.left=r.left;r1.top=r.top;r1.right=r1.left+(int)(f * w);r1.bottom=r.bottom;
   FillRect(dc,&r1,prgrsBrsh);
  break;
  case 4://downloading multipart constant part,with size:
   r1.top=r.top;r1.bottom=r.bottom;
   for(int i=0; i<myHttp::iMaxMultipart; i++)
   {if(0==memFileHeader.headers[i].state)continue;
    r1.left = 5+(int)(w * ((double)memFileHeader.headers[i].pos / (double)memFileHeader.sizeFull));
	r1.right = 5+(int)(w * ((double)(memFileHeader.headers[i].pos + memFileHeader.headers[i].downloaded) / (double)memFileHeader.sizeFull));	
	FillRect(dc,&r1,memFileHeader.headers[i].lastDownloaded?prgrsBrsh:prgrsRedBrsh);
   }
  break;
  case 5://downloading multipart dynamic part,with size:
  break;
}}