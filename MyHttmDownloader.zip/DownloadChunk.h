#ifndef _DWNLD_CHNK__H__


#include "myHttp.h"



typedef __int16 S16;
typedef __int32 S32;
typedef unsigned __int16 U16;
typedef unsigned __int32 U32;
typedef char S8;
typedef unsigned char U8;
typedef float F32;
typedef double F64;
typedef __int64 S64;
typedef unsigned __int64 U64;


#include "DMFile.h"



class ChnkHeader
{public:
	  ChnkHeader();
 bool CheckForDeprecation();
 S64  CheckForDecrement(S64*);
 bool Decrement(S64);
 void Free();
 bool Read(U32);
 bool Write();
 bool FindNewPartition(HINTERNET);
 int  FindBigChunk();
 U32  GetReadAvialable();

 S64 pos;
 S64 size;
 S64 sizeDecremented;//After cutting this chunk for new chnk to the right;
 S64 downloaded;
 DWORD lastDownloaded;
 void* buffer;
 int bufSize;
 int state;
 HINTERNET getReq;
};

__declspec(align(1)) class FileHeader
{public:
		FileHeader();
	   ~FileHeader();

  bool SetURLFromCmndLine();

 U8  flag;
 U16 MaxChnk;
 U16 URLSize;
 S64 sizeFull;
 S64 sizeDownloaded;
 wchar_t *URL, *URLhostName, *URLpath,*crFileName;
 ChnkHeader *headers;
};

extern FileHeader memFileHeader;


#endif//_DWNLD_CHNK__H__