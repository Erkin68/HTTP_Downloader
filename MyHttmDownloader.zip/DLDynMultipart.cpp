#include "myHttp.h"



namespace myHttp
{


bool DownloadDynMultipartContext()
{
 return true;
}

}//end of namespace


namespace DMFile
{


bool CheckForDMFileDynMultipartContext(HANDLE f)
{
 return false;
}

}