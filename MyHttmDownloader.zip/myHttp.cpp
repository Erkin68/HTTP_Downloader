#include "myHttp.h"
#include "DownloadChunk.h"



namespace myHttp
{

URL_COMPONENTS urlComp;
int iMaxMultipart(0),iMinMultipart(0),frstReaded(0);
float fSpeed(0.0f),fTimeToDownload(0.0f);
bool bPartialContext(false),bGlobalSizeContext(false),bPaused(false),bForceClose(false);
HINTERNET  hSession(0),hConnect(0);
DWORD RequestFlags(0);


bool Init()
{hSession = WinHttpOpen(L"myDL Program/1.0", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,//"Mozilla/5.0 (Windows; U; MSIE 9.0; WIndows NT 9.0; en-US))"
						WINHTTP_NO_PROXY_NAME,WINHTTP_NO_PROXY_BYPASS,0);//WINHTTP_FLAG_ASYNC qo'ysa, ishlamayaptur;
 if(!hSession)return false;

 hConnect = WinHttpConnect(hSession,memFileHeader.URLhostName,urlComp.nPort,0);//INTERNET_DEFAULT_PORT
 if(!hConnect)
 {WinHttpCloseHandle(hSession);
  return false;
 }

 RequestFlags = (INTERNET_SCHEME_HTTPS==urlComp.nScheme) ? WINHTTP_FLAG_SECURE : 0;//INTERNET_SCHEME_HTTPS ->2  WINHTTP_FLAG_SECURE -> 0x00800000
 //0 - INTERNET_DEFAULT_PORT; INTERNET_DEFAULT_HTTP_PORT-80; INTERNET_DEFAULT_HTTPS_PORT-443

 return true;
}

bool GetOptions()
{HINTERNET hGlobalGetRequest = CreateGetContextRange(hConnect,0,0,&bPartialContext);
 if(!hGlobalGetRequest)//return false;
  return false;

 DWORD sz[2]={36,36};void *buf=malloc(sz[0]+2);
Loop1:
 if(!WinHttpQueryHeaders(hGlobalGetRequest,WINHTTP_QUERY_CONTENT_RANGE,
	                     WINHTTP_HEADER_NAME_BY_INDEX,buf,&sz[1],WINHTTP_NO_HEADER_INDEX))
 {int err=GetLastError();
  if(ERROR_INSUFFICIENT_BUFFER==err)
  {sz[0]=sz[1];
   buf=realloc(buf,sz[0]+2); 
   goto Loop1;
  }
  if(ERROR_WINHTTP_HEADER_NOT_FOUND==err)
  {WinHttpCloseHandle(hGlobalGetRequest);
   free(buf);
   bPartialContext=false;
   return true;
  }
  WinHttpCloseHandle(hGlobalGetRequest);
  free(buf);
  return false;
 }

 wchar_t *pSizeFull = ((wchar_t*)buf) + wcslen(L"bytes 0-0/");
 memFileHeader.sizeFull = _wtoi((wchar_t*)pSizeFull);
 WinHttpCloseHandle(hGlobalGetRequest);
 bGlobalSizeContext=true;
 free(buf);
 return true;
}

bool SendFirstGetRequest()
{HINTERNET hPartialGetRequest=WinHttpOpenRequest(hConnect,
										L"GET",
										memFileHeader.URLpath,
										L"HTTP/1.0",
										WINHTTP_NO_REFERER,
										WINHTTP_DEFAULT_ACCEPT_TYPES,
										RequestFlags);
 if(!hPartialGetRequest)return 0;

 wchar_t s[64];StringCchPrintf(s,64,L"Range: bytes=%d-%d",offset,delta);int ln=(int)wcslen(s);
 if(!WinHttpSendRequest(hPartialGetRequest,s,ln,WINHTTP_NO_REQUEST_DATA,0,ln,0))
 {WinHttpCloseHandle(hPartialGetRequest);
  return 0;
 }

 if(!WinHttpReceiveResponse(hPartialGetRequest,NULL))
 {WinHttpCloseHandle(hPartialGetRequest);
  return 0;
 }
 
 DWORD sz[2]={36,36};void *buf=malloc(sz[0]+2);
Loop:
 if(!WinHttpQueryHeaders(hPartialGetRequest,WINHTTP_QUERY_STATUS_CODE,
										   WINHTTP_HEADER_NAME_BY_INDEX,
										   buf,&sz[1],
										   WINHTTP_NO_HEADER_INDEX))
 {if(ERROR_INSUFFICIENT_BUFFER==GetLastError())
  {sz[0]=sz[1];
   buf=realloc(buf,sz[0]+2);
   goto Loop;
  }
  WinHttpCloseHandle(hPartialGetRequest);
  free(buf);
  return NULL;
 }if(sz[0]>sz[1])sz[1]=sz[0];

 DWORD statusCode = _wtoi((wchar_t*)buf);
 if(statusCode == HTTP_STATUS_PARTIAL_CONTENT)//206 - HTTP_STATUS_PARTIAL_CONTENT;
  (*bPartialContext)=true;
 else (*bPartialContext)=false;
 free(buf);
 return hPartialGetRequest;
}

 wchar_t *pSizeFull = ((wchar_t*)buf) + wcslen(L"bytes 0-0/");
 memFileHeader.sizeFull = _wtoi((wchar_t*)pSizeFull);
 WinHttpCloseHandle(hGlobalGetRequest);
 bGlobalSizeContext=true;
 free(buf);
 return true;
}

void Close()
{if(hConnect)WinHttpCloseHandle(hConnect);hConnect=0;
 if(hSession)WinHttpCloseHandle(hSession);hSession=0;
}



}//end of namespace