#ifndef _myHTTP_H__
#define _myHTTP_H__

#include "windows.h"
#include "winhttp.h"

typedef unsigned __int64 U64;
typedef signed __int64 S64;

namespace myHttp
{

extern int iMaxMultipart,iMinMultipart,frstReaded;
extern float fSpeed,fTimeToDownload;
extern bool bPartialContext,bGlobalSizeContext,bPaused,bForceClose;
extern HINTERNET hSession,hConnect;
extern URL_COMPONENTS urlComp;
extern DWORD RequestFlags;

extern wchar_t ErrString[260];

extern bool Init();
extern void Close();
extern bool GetOptions();


extern HINTERNET CreateGetContextRange(HINTERNET,S64,S64,bool*);
extern bool DownloadSingleUnknownSize();
extern bool DownloadSingleWithSize();
extern bool DownloadConstMultipartContext();
extern bool DownloadDynMultipartContext();


extern bool SendToExtMaster(wchar_t*,int,S64);

}

#endif
