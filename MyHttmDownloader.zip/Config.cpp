#include "windows.h"
#include "stdio.h"
#include "config.h"
#include "strsafe.h"


namespace config
{

wchar_t outDir[MAX_PATH*2]=L"";
Bools bools(0);
int iMaxMultipart(10),iMinMultipart(4);


void SetDefault()
{bools=0;
 iMaxMultipart=8;
 iMinMultipart=4;
 int l=GetTempPath(MAX_PATH*2,outDir);
 if(0==l)StringCchPrintf(outDir,4,L"C:\\");
}

void Save()
{wchar_t s[512];GetModuleFileName(NULL,s,512);
 wchar_t *p=wcsrchr(s,'\\');
 if(p)StringCchPrintf(p+1,(int)(p-&s[0]),L"conf.bin");
 else StringCchPrintf(s,512,L"conf.bin");
 FILE *f=0;_wfopen_s(&f,s,L"wb");

 fwrite(&bools,sizeof(Bools),1,f);
 fwrite(&iMaxMultipart,sizeof(iMaxMultipart),1,f);
 fwrite(&iMinMultipart,sizeof(iMinMultipart),1,f);

 __int16 l=(__int16)wcslen(outDir);
 fwrite(&l,sizeof(__int16),1,f);
 fwrite(outDir,sizeof(__int16),l,f);
 fclose(f);
}

void Read()
{
/*	DWORD al[]={1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10};
	DWORD al1[]={11,12,13,14,15,16,17,18,19,20,11,12,13,14,15,16,17,18,19,20,11,12,13,14,15,16,17,18,19,20,11,12,13,14,15,16,17,18,19,20};
	FILE *f=fopen("al.al:stream1","wb");
	fwrite(al,4,40,f);

	fpos_t t=4000;
	fsetpos(f,&t);
	fwrite(al,4,40,f);

	fclose(f);
	f=fopen("al.al:stream2","wb");
	fwrite(al1,4,40,f);

	fsetpos(f,&t);
	fwrite(al,4,40,f);

	fclose(f);

	DWORD al[40],al1[40];
	FILE *f=fopen("al.al:stream1","rb");
	fread(al,4,40,f);
	fclose(f);
	f=fopen("al.al:stream2","rb");
	fread(al1,4,40,f);
	fclose(f);*/



	
 wchar_t s[512];GetModuleFileName(NULL,s,512);
 wchar_t *p=wcsrchr(s,'\\');
 if(p)StringCchPrintf(p+1,(int)(p-&s[0]),L"conf.bin");
 else StringCchPrintf(s,512,L"conf.bin");
 FILE *f=0;_wfopen_s(&f,s,L"rb");
 if(!f)
 {SetDefault();
  Save();
  return;
 }

 fread(&bools,sizeof(Bools),1,f);
 fread(&iMaxMultipart,sizeof(iMaxMultipart),1,f);//iMaxMultipart=10;
 fread(&iMinMultipart,sizeof(iMinMultipart),1,f);//iMinMultipart=10;

 __int16 l;fread(&l,sizeof(__int16),1,f);
 fread(outDir,sizeof(__int16),l,f);
 outDir[l]=0;

 fclose(f);
}



}