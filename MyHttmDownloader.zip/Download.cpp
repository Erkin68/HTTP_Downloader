#include "DownloadChunk.h"
#include "DMFile.h"
#include <shlwapi.h>
#include "config.h"
#include "myHttp.h"
#include "Win7ProgressTaskbar.h"
#include "strsafe.h"


extern HWND hWnd;
FileHeader memFileHeader;

extern bool DownloadSingleUnknownSize();
extern bool DownloadSingleWithSize();
extern bool DownloadConstMultipartContext();
extern bool DownloadMultipartContext();


FileHeader::FileHeader():URL(0),URLhostName(0),URLSize(0),URLpath(0),crFileName(0),sizeFull(-1),sizeDownloaded(0),
						 flag(0),MaxChnk(0){}
FileHeader::~FileHeader()
{/*if(URL)free(URL);*/URL=0;
 /*if(URLhostName)free(URLhostName);*/URLhostName=0;
 /*if(URLpath)free(URLpath);*/URLpath=0;
 /*if(crFileName)free(crFileName);*/crFileName=0; 
}//malloc process heap free dan keyin xato beradur;

//class FileHeader:
//class FileHeader:
//class FileHeader:
//class FileHeader:
bool FileHeader::SetURLFromCmndLine()
{wchar_t pth[512];GetModuleFileName(0,pth,512);
 int ln = (int)wcslen(pth)+3;wchar_t *cmdLn = GetCommandLineW();
 URLSize = (U16)wcslen(&cmdLn[ln])+1;
 if(URLSize<6)return false;
 URL = (wchar_t*)malloc(URLSize*sizeof(U16));
 StringCchPrintf((wchar_t*)URL,URLSize,&cmdLn[ln]);

 //cracking URL:
 DWORD dwUrlLen = 0;
 ZeroMemory(&myHttp::urlComp, sizeof(myHttp::urlComp));
 myHttp::urlComp.dwStructSize = sizeof(myHttp::urlComp);
 myHttp::urlComp.dwSchemeLength=myHttp::urlComp.dwHostNameLength=myHttp::urlComp.dwUrlPathLength=myHttp::urlComp.dwExtraInfoLength=-1;
 if(!WinHttpCrackUrl(URL,memFileHeader.URLSize, 0, &myHttp::urlComp))
 {//printf("Error %u in WinHttpCrackUrl.\n", GetLastError());
 }

 if((DWORD)(-1)==myHttp::urlComp.dwHostNameLength)return false;
 if((DWORD)(-1)==myHttp::urlComp.dwUrlPathLength)return false;
 if((DWORD)(-1)==myHttp::urlComp.dwSchemeLength)return false;
 if((DWORD)(-1)==myHttp::urlComp.dwExtraInfoLength)return false;

 URLhostName = (wchar_t*)malloc((myHttp::urlComp.dwHostNameLength+1)*sizeof(wchar_t));
 memcpy(URLhostName,myHttp::urlComp.lpszHostName,myHttp::urlComp.dwHostNameLength*sizeof(wchar_t));
 URLhostName[myHttp::urlComp.dwHostNameLength]=0;

 int totURLpathLn=myHttp::urlComp.dwUrlPathLength+myHttp::urlComp.dwExtraInfoLength;
 URLpath = (wchar_t*)malloc(totURLpathLn*sizeof(wchar_t));
 memcpy(URLpath,myHttp::urlComp.lpszUrlPath,totURLpathLn*sizeof(wchar_t));
 URLpath[totURLpathLn]=0;

 //Find file name from command line arguments php - > GET:
 int iAsterPos=0;//,iArgs=0;
 for(int i=0; i<totURLpathLn; i++)
 {if('?'==URLpath[i])
  {if(iAsterPos<0)
    iAsterPos=i;
  }//else if('&'==URLpath[i])
   // iArgs++;
  else if('='==URLpath[i] && i<totURLpathLn && iAsterPos>-1)
  {if(!crFileName)
   {crFileName=(wchar_t*)malloc((totURLpathLn-i+1)*sizeof(wchar_t));
    StringCchPrintf(crFileName,totURLpathLn-i+1,&URLpath[i+1]);
	wchar_t *p=wcschr(crFileName,'&');
	if(p)*p=0;
	p=wcschr(crFileName,'=');
	if(p)*p=0;
	break;
 }}}
 if(!crFileName)
 {crFileName=URLpath;//(wchar_t*)malloc((totURLpathLn)*sizeof(wchar_t));
  //wcscpy(crFileName,URLpath);
 }
 return true;
}

void DownloadThread()
{bool r=false;
 SendMessage(hWnd,WM_USER,0,1);
 
#define CheckPause	if(myHttp::bForceClose)goto End;\
					if(myHttp::bPaused)\
					{for(;myHttp::bPaused && (!myHttp::bForceClose);)\
					  Sleep(500);\
					}else Sleep(500);					

 for(;!DMFile::Open();){CheckPause SendMessage(hWnd,WM_USER,0,2);}
 //{MessageBox(wnd,L"Error creating download file",L"Quiting...",MB_OK);
 // return -1;
 //}
 SendMessage(hWnd,WM_USER,0,3);
 for(;!myHttp::Init();){CheckPause SendMessage(hWnd,WM_USER,0,4);}
 //{MessageBox(wnd,L"Error creating Http queue",L"Quiting...",MB_OK);
 // return -1;
 //}
 //Win7PrgrsTaskbar::Send(75);
 SendMessage(hWnd,WM_USER,0,5);
 //for(;!myHttp::GetOptions();){CheckPause SendMessage(hWnd,WM_USER,0,6);}
 for(;!myHttp::SendFirstGetRequest();){CheckPause SendMessage(hWnd,WM_USER,0,6);}

 //{MessageBox(wnd,L"Error getting file size.",L"Quiting...",MB_OK);
 // return -1;
 //}
 SendMessage(hWnd,WM_USER,0,7);

 //if((!myHttp::bGlobalSizeContext) || (-1==memFileHeader.sizeFull))
 //{SendMessage(hWnd,WM_USER,0,8);
 // r=myHttp::DownloadSingleUnknownSize();
 //}
 //else if(!myHttp::bPartialContext)
 {SendMessage(hWnd,WM_USER,0,9);
  r=myHttp::DownloadSingleWithSize();
 }
 //else if(config::bools.bConstMultipart)
 //{SendMessage(hWnd,WM_USER,0,10);
 // r=myHttp::DownloadConstMultipartContext();
 //}
/*else
 {SendMessage(hWnd,WM_USER,0,11);
  r=myHttp::DownloadMultipartContext();
 }*/
 SendMessage(hWnd,WM_USER,0,12);
End:
 DMFile::Close(r);
 myHttp::Close();
 SendMessage(hWnd,WM_DESTROY,0,0);
#undef CheckPause
}