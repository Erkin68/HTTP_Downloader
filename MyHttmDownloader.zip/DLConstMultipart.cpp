// HANDLE f = CreateFile(L"pth.txt",GENERIC_WRITE,FILE_SHARE_WRITE,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
// DWORD d = SetFilePointer(f,5000,NULL,FILE_BEGIN);
// BOOL b = WriteFile(f,L"Assalom",8,0,NULL);
// CloseHandle(f);Hech narsa yozmasdan ham pointerini surish mumkin,faqat undan so'ng yozish amaliyoti bo'lishi shart.
// Hamma amallarimiz shuning asosida olib boriladi!!!
#include "myHttp.h"
#include "DownloadChunk.h"
#include "strsafe.h"
#include "Win7ProgressTaskbar.h"
#include "DMFile.h"
#include "config.h"


extern HWND hWnd;


namespace myHttp
{

void WriteHeaders()
{DWORD writed;LONG l[2]={memFileHeader.sizeFull & 0xffffffff,memFileHeader.sizeFull>>32};
 SetFilePointer(DMFile::f,l[0],&l[1],FILE_BEGIN);
 WriteFile(DMFile::f,memFileHeader.headers,myHttp::iMaxMultipart*sizeof(ChnkHeader),&writed,NULL);
 WriteFile(DMFile::f,memFileHeader.URL,memFileHeader.URLSize*sizeof(wchar_t),&writed,NULL);
 WriteFile(DMFile::f,&memFileHeader,sizeof(memFileHeader),&writed,NULL);
}

bool DownloadConstMultipartContext()
{bool r=false;
 memFileHeader.sizeDownloaded=0;
 memFileHeader.MaxChnk=1;
 memFileHeader.flag=2;
 memFileHeader.headers = (ChnkHeader*)malloc(config::iMaxMultipart*sizeof(ChnkHeader));
 if(!memFileHeader.headers)goto End;
 for(int i=0; i<config::iMaxMultipart; i++)memFileHeader.headers[i].ChnkHeader::ChnkHeader();
 
 memFileHeader.headers[0].pos=0;
 memFileHeader.headers[0].downloaded=0;
 memFileHeader.headers[0].size=memFileHeader.sizeFull;

 S64 chnkDelta = memFileHeader.sizeFull / (config::iMaxMultipart > 1 ? config::iMaxMultipart-1 : 1);
 if(chnkDelta>memFileHeader.sizeFull)chnkDelta=(DWORD)memFileHeader.sizeFull;
 myHttp::iMaxMultipart = (int)(chnkDelta>0 ? (memFileHeader.sizeFull / chnkDelta) : 1);
 myHttp::iMinMultipart = config::iMinMultipart<myHttp::iMaxMultipart ? config::iMinMultipart : iMaxMultipart;

 S64 d = memFileHeader.sizeFull % chnkDelta;
 {if(d && (d > chnkDelta / 2))
   ++myHttp::iMaxMultipart;
 }

 S64 offset=0;
 for(int i=0; i<myHttp::iMaxMultipart; i++)
 {if(i==myHttp::iMaxMultipart-1)
   chnkDelta=memFileHeader.sizeFull-offset;
  bool bPartialContext;
  memFileHeader.headers[i].getReq = CreateGetContextRange(hConnect,offset,offset+chnkDelta-1,&bPartialContext);
  if(memFileHeader.headers[i].getReq)
  {memFileHeader.headers[i].pos=offset;
   memFileHeader.headers[i].size=chnkDelta-1;
   memFileHeader.headers[i].state=1;
  }
  offset+=chnkDelta;
 }

 memFileHeader.sizeDownloaded=0;//SetFilePointer(DMFile::f,0,NULL,FILE_BEGIN); kerak emas, har biri o'zinikini yaxshi biladur;
 fSpeed = 0.0f;fTimeToDownload = 0.0f;DWORD gtck = GetTickCount();
 do 
 {//int perc = 0;
  //SendToPaint();
  //if(perc!=percent)
  //{SendToExtMaster(memFileHeader.URLpath,perc,memFileHeader.sizeFull);
  //Win7PrgrsTaskbar::Send(perc);
  //percent=perc;}
  DWORD dwDownloaded=0;int workingParts=0;
  for(int i=0; i<myHttp::iMaxMultipart; i++)
  {if(memFileHeader.headers[i].state)
   {U32 av = memFileHeader.headers[i].GetReadAvialable();
    if(av)
    {memFileHeader.headers[i].Read(av);
     memFileHeader.headers[i].Write();
	 dwDownloaded += memFileHeader.headers[i].lastDownloaded;
	 memFileHeader.headers[i].CheckForDeprecation();
     WriteHeaders();
    }++workingParts;
  }}
  if(workingParts<myHttp::iMinMultipart)
  {for(int i=0; i<myHttp::iMaxMultipart; i++)
   {if(!memFileHeader.headers[i].state)
     memFileHeader.headers[i].FindNewPartition(hConnect);
  }}

  memFileHeader.sizeDownloaded += dwDownloaded;
  Win7PrgrsTaskbar::Send();
  SendMessage(hWnd,WM_USER,0,10);
  //{SendToExtMaster(memFileHeader.URLpath,Win7PrgsTaskbar::perc,memFileHeader.sizeFull);
  DWORD gtcke = GetTickCount();

  if(bPaused)
  {for(;bPaused;)Sleep(500);
   gtcke = gtck = GetTickCount();
   fSpeed = 0.0f;
  }
  else
  {DWORD delta = gtcke>gtck?gtcke-gtck:0;
   fTimeToDownload += delta;
   gtck = gtcke;
   if(delta && dwDownloaded && memFileHeader.sizeDownloaded != dwDownloaded)
    fSpeed = (float)((double)dwDownloaded / (double)delta);
 }}
 while(memFileHeader.sizeDownloaded<memFileHeader.sizeFull && (!bForceClose));

 if(memFileHeader.sizeDownloaded==memFileHeader.sizeFull)
 {r=true;LONG l[2]={memFileHeader.sizeFull & 0xffffffff, memFileHeader.sizeFull>>32};
  SetFilePointer(DMFile::f,l[0],&l[1],FILE_BEGIN);
  SetEndOfFile(DMFile::f);
 }
End:
 for(int i=1; i<myHttp::iMaxMultipart; i++)
  memFileHeader.headers[i].Free();
 if(memFileHeader.headers)free(memFileHeader.headers);
 return r;
}

HINTERNET CreateGetContextRange(HINTERNET hConnect,S64 offset,S64 delta,bool *bPartialContext)
{HINTERNET hPartialGetRequest=WinHttpOpenRequest(hConnect,
										L"GET",
										memFileHeader.URLpath,0/*L"HTTP/1.1"*/,
										WINHTTP_NO_REFERER,WINHTTP_DEFAULT_ACCEPT_TYPES,RequestFlags);
 if(!hPartialGetRequest)return 0;

 wchar_t s[64];StringCchPrintf(s,64,L"Range: bytes=%d-%d",offset,delta);int ln=(int)wcslen(s);
 if(!WinHttpSendRequest(hPartialGetRequest,s,ln,WINHTTP_NO_REQUEST_DATA,0,ln,0))
 {WinHttpCloseHandle(hPartialGetRequest);
  return 0;
 }

 if(!WinHttpReceiveResponse(hPartialGetRequest,NULL))
 {WinHttpCloseHandle(hPartialGetRequest);
  return 0;
 }
 
 DWORD sz[2]={36,36};void *buf=malloc(sz[0]+2);
Loop:
 if(!WinHttpQueryHeaders(hPartialGetRequest,WINHTTP_QUERY_STATUS_CODE,
										   WINHTTP_HEADER_NAME_BY_INDEX,
										   buf,&sz[1],
										   WINHTTP_NO_HEADER_INDEX))
 {if(ERROR_INSUFFICIENT_BUFFER==GetLastError())
  {sz[0]=sz[1];
   buf=realloc(buf,sz[0]+2);
   goto Loop;
  }
  WinHttpCloseHandle(hPartialGetRequest);
  free(buf);
  return NULL;
 }if(sz[0]>sz[1])sz[1]=sz[0];

 DWORD statusCode = _wtoi((wchar_t*)buf);
 if(statusCode == HTTP_STATUS_PARTIAL_CONTENT)//206 - HTTP_STATUS_PARTIAL_CONTENT;
  (*bPartialContext)=true;
 else (*bPartialContext)=false;
 free(buf);
 return hPartialGetRequest;
}


}//end of namespace



namespace DMFile 
{

bool CheckForDMFileConstMultipartContext(HANDLE f)
{
 return false;
}


}