#include "DownloadChunk.h"
#include "strsafe.h"


ChnkHeader::ChnkHeader():buffer(0),bufSize(0),sizeDecremented(0),downloaded(0),lastDownloaded(0),state(0)
{
}

void ChnkHeader::Free()
{if(buffer)free(buffer);buffer=0;
 bufSize=0;state=0;
 if(getReq)WinHttpCloseHandle(getReq);getReq=0;
}

bool ChnkHeader::Read(U32 avlSz)
{DWORD sz=avlSz;
 if(!sz)for(;!WinHttpQueryDataAvailable(getReq,&sz);)Sleep(50);
 if(sz>(DWORD)bufSize)
 {if(buffer)buffer = (char*)realloc(buffer,sz+2);
  else buffer = (char*)malloc(sz+2);
  if(!buffer)
  {StringCchPrintf(myHttp::ErrString,260,L"Out of memory");
   return false;
  }bufSize=sz;
 }//ZeroMemory(buffer, sz);
 //lastDownloaded=0; avial ga ko'chdi;
 if(!WinHttpReadData(getReq,(LPVOID)buffer,sz,&lastDownloaded))
 {StringCchPrintf(myHttp::ErrString,260,L"Err. WinHttpReadData");
  return false;
 }downloaded+=lastDownloaded;
 if(0==state)state=1;
 return true;
}

bool ChnkHeader::Write()
{DWORD writed;S64 crntPos = pos+downloaded-lastDownloaded;
 LONG dwPos[2]={crntPos & 0xffffffff, crntPos>>32};
 writed=SetFilePointer(DMFile::f,dwPos[0],&dwPos[1],FILE_BEGIN);
 if(2==state)//decremented for new partition on the right;
 {if(downloaded>=sizeDecremented)
  {lastDownloaded -= (DWORD)(downloaded-sizeDecremented);
   state = 3;//deprecated;
 }}
 WriteFile(DMFile::f,buffer,lastDownloaded,&writed,NULL);//dwonloaded size kerak emas;
 return true;
}

bool ChnkHeader::CheckForDeprecation()
{if(3!=state)return false;
 pos=0;
 downloaded=0;
 lastDownloaded=0;
 size=0;
 sizeDecremented=0;
 if(getReq)WinHttpCloseHandle(getReq);getReq=0;
 state=0;
 return true;
}

S64 ChnkHeader::CheckForDecrement(S64 *sz)//2 ga bo'lsa bo'ladimi?
{S64 crntPos = pos + downloaded;
 if(0==sizeDecremented)
 {if(crntPos >= size)return 0;
  S64 undld = (size - crntPos)/2;
  undld &= ~(myHttp::frstReaded-1);
  *sz = size - undld;
  return undld;
 }//else, if decremented:
 if(crntPos >= sizeDecremented)return 0;
 S64 undld = (sizeDecremented - crntPos)/2;
 undld &= ~(myHttp::frstReaded-1);
 *sz = sizeDecremented - undld;
 return undld;
}

bool ChnkHeader::Decrement(S64 decrPos)//2 ga bo'lish.
{S64 crntPos = pos + downloaded; 
 if(crntPos >= decrPos)return false;
 if(0!=sizeDecremented && decrPos>=sizeDecremented)return false;
 sizeDecremented = decrPos;
 state = 2;//decremented,2 ga bo'lingan;
 return true;
}

bool ChnkHeader::FindNewPartition(HINTERNET hConnect)
{if(getReq)return false;
 int iBigChnkNum = FindBigChunk();
 if(-1==iBigChnkNum)return false;
 S64 sz=0,pstn=memFileHeader.headers[iBigChnkNum].CheckForDecrement(&sz);
 if(pstn)
 {bool bPartialContext;HINTERNET h=myHttp::CreateGetContextRange(hConnect,pstn,sz,&bPartialContext);
  if(!h)return false;
  getReq = h;
  downloaded = 0;
  lastDownloaded = 0;
  pos = pstn;
  size = sz;
  sizeDecremented = 0;
  state = 1;
  memFileHeader.headers[iBigChnkNum].Decrement(pstn);
 }
 return true;
}

U32 ChnkHeader::GetReadAvialable()
{DWORD sz=0;lastDownloaded=0;
 if(WinHttpQueryDataAvailable(getReq,&sz))
  return sz;
 return 0;
}

int ChnkHeader::FindBigChunk()
{S64 szMax=0;int imax=-1;
 for(int i=0; i<myHttp::iMaxMultipart; i++)
 {S64 unloaded = memFileHeader.headers[i].size-memFileHeader.headers[i].downloaded;
  if(unloaded>szMax){szMax=unloaded;imax=i;}
 }return imax;
}
